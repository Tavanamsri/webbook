<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';
include '../classes/Product.php';
include '../classes/Faculty.php';
include '../classes/Department.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

$productClass = new Product();
$facultyClass = new Faculty();
$departmentClass = new Department();

$faculties = $facultyClass->getAllFaculties();

// การจัดการการเพิ่ม ลบ แก้ไข สินค้า
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_product'])) {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];
        $faculty_id = $_POST['faculty_id'];
        $department_id = $_POST['department_id'];

        // การอัปโหลดรูปภาพ
        $image = $_FILES['image']['name'];
        $target = "../assets/images/" . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);

        $productClass->addProduct($name, $description, $price, $stock, $faculty_id, $department_id, $image);
        header('Location: manage_products.php');
        exit();
    }

    if (isset($_POST['edit_product'])) {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];
        $faculty_id = $_POST['faculty_id'];
        $department_id = $_POST['department_id'];

        // การอัปโหลดรูปภาพใหม่ถ้ามี
        if ($_FILES['image']['name']) {
            $image = $_FILES['image']['name'];
            $target = "../assets/images/" . basename($image);
            move_uploaded_file($_FILES['image']['tmp_name'], $target);
        } else {
            $image = $_POST['existing_image'];
        }

        $productClass->updateProduct($id, $name, $description, $price, $stock, $faculty_id, $department_id, $image);
        header('Location: manage_products.php');
        exit();
    }

    if (isset($_POST['delete_product'])) {
        $id = $_POST['id'];

        $productClass->deleteProduct($id);
        header('Location: manage_products.php');
        exit();
    }
}

// ดึงข้อมูลสินค้าทั้งหมด
$products = $productClass->getAllProducts();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/admin_header.php'; ?>
    <title>จัดการสินค้า</title>
</head>
<body>
    <?php include '../includes/admin_navbar.php'; ?>

    <div class="container mt-5">
        <h2>จัดการสินค้า</h2>

        <!-- ฟอร์มเพิ่มสินค้า -->
        <h4>เพิ่มสินค้าใหม่</h4>
        <form action="" method="post" enctype="multipart/form-data" class="mb-4">
            <div class="mb-3">
                <label>ชื่อสินค้า</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>คำอธิบาย</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <div class="mb-3">
                <label>ราคา</label>
                <input type="number" name="price" class="form-control" step="0.01" required>
            </div>
            <div class="mb-3">
                <label>จำนวนในสต็อก</label>
                <input type="number" name="stock" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>คณะ</label>
                <select name="faculty_id" id="faculty" class="form-control">
                    <option value="">-- เลือกคณะ --</option>
                    <?php foreach ($faculties as $faculty): ?>
                        <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>สาขาวิชา</label>
                <select name="department_id" id="department" class="form-control">
                    <option value="">-- เลือกสาขาวิชา --</option>
                    <!-- สาขาวิชาจะถูกโหลดโดย JavaScript -->
                </select>
            </div>
            <div class="mb-3">
                <label>รูปภาพสินค้า</label>
                <input type="file" name="image" class="form-control" required>
            </div>
            <button type="submit" name="add_product" class="btn btn-success">เพิ่มสินค้า</button>
        </form>

        <!-- ตารางแสดงสินค้า -->
        <h4>รายการสินค้าทั้งหมด</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ชื่อสินค้า</th>
                    <th>ราคา</th>
                    <th>สต็อก</th>
                    <th>คณะ</th>
                    <th>สาขาวิชา</th>
                    <th>รูปภาพ</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo number_format($product['price'], 2); ?> บาท</td>
                        <td><?php echo $product['stock']; ?></td>
                        <td><?php echo htmlspecialchars($product['faculty_name']); ?></td>
                        <td><?php echo htmlspecialchars($product['department_name']); ?></td>
                        <td><img src="../assets/images/<?php echo $product['image']; ?>" width="100" alt="<?php echo htmlspecialchars($product['name']); ?>"></td>
                        <td>
                            <!-- ปุ่มแก้ไขและลบ -->
                            <form action="" method="post" enctype="multipart/form-data" class="d-inline">
                                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                <input type="hidden" name="existing_image" value="<?php echo $product['image']; ?>">
                                <button type="button" class="btn btn-primary btn-sm edit-btn" data-product='<?php echo json_encode($product); ?>'>แก้ไข</button>
                                <button type="submit" name="delete_product" class="btn btn-danger btn-sm" onclick="return confirm('คุณต้องการลบสินค้านี้หรือไม่?')">ลบ</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- โมดอลสำหรับแก้ไขสินค้า -->
        <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <form action="" method="post" enctype="multipart/form-data" class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">แก้ไขสินค้า</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" name="id" id="edit-id">
                <input type="hidden" name="existing_image" id="edit-existing-image">
                <div class="mb-3">
                    <label>ชื่อสินค้า</label>
                    <input type="text" name="name" id="edit-name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>คำอธิบาย</label>
                    <textarea name="description" id="edit-description" class="form-control"></textarea>
                </div>
                <div class="mb-3">
                    <label>ราคา</label>
                    <input type="number" name="price" id="edit-price" class="form-control" step="0.01" required>
                </div>
                <div class="mb-3">
                    <label>จำนวนในสต็อก</label>
                    <input type="number" name="stock" id="edit-stock" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>คณะ</label>
                    <select name="faculty_id" id="edit-faculty" class="form-control">
                        <option value="">-- เลือกคณะ --</option>
                        <?php foreach ($faculties as $faculty): ?>
                            <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label>สาขาวิชา</label>
                    <select name="department_id" id="edit-department" class="form-control">
                        <option value="">-- เลือกสาขาวิชา --</option>
                        <!-- สาขาวิชาจะถูกโหลดโดย JavaScript -->
                    </select>
                </div>
                <div class="mb-3">
                    <label>รูปภาพสินค้า (ถ้าไม่เปลี่ยนไม่ต้องเลือก)</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <img id="edit-image-preview" src="" width="100" alt="">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="submit" name="edit_product" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
              </div>
            </form>
          </div>
        </div>
    </div>

    <?php include '../includes/admin_footer.php'; ?>

    <!-- JavaScript สำหรับจัดการโมดอลและโหลดสาขาวิชา -->
    <script>
        // โหลดสาขาวิชาในฟอร์มเพิ่มสินค้า
        document.getElementById('faculty').addEventListener('change', function() {
            var faculty_id = this.value;
            loadDepartments(faculty_id, 'department');
        });

        function loadDepartments(faculty_id, department_element_id, selected_department_id = null) {
            if (faculty_id) {
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '../pages/get_departments.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    document.getElementById(department_element_id).innerHTML = this.responseText;
                    if (selected_department_id) {
                        document.getElementById(department_element_id).value = selected_department_id;
                    }
                };
                xhr.send('faculty_id=' + faculty_id);
            } else {
                document.getElementById(department_element_id).innerHTML = '<option value="">-- เลือกสาขาวิชา --</option>';
            }
        }

        // จัดการโมดอลแก้ไขสินค้า
        document.querySelectorAll('.edit-btn').forEach(function(button) {
            button.addEventListener('click', function() {
                var product = JSON.parse(this.dataset.product);

                document.getElementById('edit-id').value = product.id;
                document.getElementById('edit-existing-image').value = product.image;
                document.getElementById('edit-name').value = product.name;
                document.getElementById('edit-description').value = product.description;
                document.getElementById('edit-price').value = product.price;
                document.getElementById('edit-stock').value = product.stock;
                document.getElementById('edit-faculty').value = product.faculty_id;
                document.getElementById('edit-image-preview').src = '../assets/images/' + product.image;

                loadDepartments(product.faculty_id, 'edit-department', product.department_id);

                var editModal = new bootstrap.Modal(document.getElementById('editModal'));
                editModal.show();
            });
        });

        // โหลดสาขาวิชาในฟอร์มแก้ไขสินค้า
        document.getElementById('edit-faculty').addEventListener('change', function() {
            var faculty_id = this.value;
            loadDepartments(faculty_id, 'edit-department');
        });
    </script>
</body>
</html>
