<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';
include '../classes/User.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

$userClass = new User();

// การจัดการการเพิ่ม ลบ แก้ไข ผู้ใช้
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['edit_user'])) {
        $id = $_POST['id'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $role = $_POST['role'];

        $userClass->adminUpdateUser($id, $firstname, $lastname, $email, $phone, $role);
        header('Location: manage_users.php');
        exit();
    }

    if (isset($_POST['delete_user'])) {
        $id = $_POST['id'];

        $userClass->deleteUser($id);
        header('Location: manage_users.php');
        exit();
    }
}

// ดึงข้อมูลผู้ใช้ทั้งหมด
$users = $userClass->getAllUsers();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/admin_header.php'; ?>
    <title>จัดการผู้ใช้</title>
</head>
<body>
    <?php include '../includes/admin_navbar.php'; ?>

    <div class="container mt-5">
        <h2>จัดการผู้ใช้</h2>

        <!-- ตารางแสดงผู้ใช้ -->
        <h4>รายการผู้ใช้ทั้งหมด</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ชื่อ</th>
                    <th>อีเมล</th>
                    <th>เบอร์โทรศัพท์</th>
                    <th>บทบาท</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['phone']); ?></td>
                        <td><?php echo htmlspecialchars($user['role']); ?></td>
                        <td>
                            <!-- ปุ่มแก้ไขและลบ -->
                            <form action="" method="post" class="d-inline">
                                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                <button type="button" class="btn btn-primary btn-sm edit-btn" data-user='<?php echo json_encode($user); ?>'>แก้ไข</button>
                                <button type="submit" name="delete_user" class="btn btn-danger btn-sm" onclick="return confirm('คุณต้องการลบผู้ใช้นี้หรือไม่?')">ลบ</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- โมดอลสำหรับแก้ไขผู้ใช้ -->
        <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <form action="" method="post" class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">แก้ไขผู้ใช้</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" name="id" id="edit-id">
                <div class="mb-3">
                    <label>ชื่อ</label>
                    <input type="text" name="firstname" id="edit-firstname" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>นามสกุล</label>
                    <input type="text" name="lastname" id="edit-lastname" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>อีเมล</label>
                    <input type="email" name="email" id="edit-email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>เบอร์โทรศัพท์</label>
                    <input type="tel" name="phone" id="edit-phone" class="form-control">
                </div>
                <div class="mb-3">
                    <label>บทบาท</label>
                    <select name="role" id="edit-role" class="form-control">
                        <option value="user">ผู้ใช้ทั่วไป</option>
                        <option value="admin">ผู้ดูแลระบบ</option>
                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="submit" name="edit_user" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
              </div>
            </form>
          </div>
        </div>
    </div>

    <?php include '../includes/admin_footer.php'; ?>

    <!-- JavaScript สำหรับจัดการโมดอล -->
    <script>
        document.querySelectorAll('.edit-btn').forEach(function(button) {
            button.addEventListener('click', function() {
                var user = JSON.parse(this.dataset.user);

                document.getElementById('edit-id').value = user.id;
                document.getElementById('edit-firstname').value = user.firstname;
                document.getElementById('edit-lastname').value = user.lastname;
                document.getElementById('edit-email').value = user.email;
                document.getElementById('edit-phone').value = user.phone;
                document.getElementById('edit-role').value = user.role;

                var editModal = new bootstrap.Modal(document.getElementById('editModal'));
                editModal.show();
            });
        });
    </script>
</body>
</html>
