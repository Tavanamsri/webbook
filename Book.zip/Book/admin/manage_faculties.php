<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';
include '../classes/Faculty.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

$facultyClass = new Faculty();
$faculties = $facultyClass->getAllFaculties();

// การจัดการการเพิ่ม ลบ แก้ไข คณะ
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_faculty'])) {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $description = $_POST['description'];

        $facultyClass->addFaculty($id, $name, $description);
        header('Location: manage_faculties.php');
        exit();
    }

    if (isset($_POST['edit_faculty'])) {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $description = $_POST['description'];

        $facultyClass->updateFaculty($id, $name, $description);
        header('Location: manage_faculties.php');
        exit();
    }

    if (isset($_POST['delete_faculty'])) {
        $id = $_POST['id'];

        $facultyClass->deleteFaculty($id);
        header('Location: manage_faculties.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/admin_header.php'; ?>
    <title>จัดการคณะ</title>
</head>
<body>
    <?php include '../includes/admin_navbar.php'; ?>

    <div class="container mt-5">
        <h2>จัดการคณะ</h2>

        <!-- ฟอร์มเพิ่มคณะ -->
        <h4>เพิ่มคณะใหม่</h4>
        <form action="" method="post" class="mb-4">
            <div class="mb-3">
                <label>ID คณะ</label>
                <input type="text" name="id" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>ชื่อคณะ</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>คำอธิบาย</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <button type="submit" name="add_faculty" class="btn btn-success">เพิ่มคณะ</button>
        </form>

        <!-- ตารางแสดงคณะ -->
        <h4>รายการคณะทั้งหมด</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID คณะ</th>
                    <th>ชื่อคณะ</th>
                    <th>คำอธิบาย</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($faculties as $faculty): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($faculty['id']); ?></td>
                        <td><?php echo htmlspecialchars($faculty['name']); ?></td>
                        <td><?php echo htmlspecialchars($faculty['description']); ?></td>
                        <td>
                            <!-- ปุ่มแก้ไขและลบ -->
                            <form action="" method="post" class="d-inline">
                                <input type="hidden" name="id" value="<?php echo $faculty['id']; ?>">
                                <button type="button" class="btn btn-primary btn-sm edit-btn" data-id="<?php echo $faculty['id']; ?>" data-name="<?php echo htmlspecialchars($faculty['name']); ?>" data-description="<?php echo htmlspecialchars($faculty['description']); ?>">แก้ไข</button>
                                <button type="submit" name="delete_faculty" class="btn btn-danger btn-sm" onclick="return confirm('คุณต้องการลบคณะนี้หรือไม่?')">ลบ</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- โมดอลสำหรับแก้ไขคณะ -->
        <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <form action="" method="post" class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">แก้ไขคณะ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" name="id" id="edit-id">
                <div class="mb-3">
                    <label>ชื่อคณะ</label>
                    <input type="text" name="name" id="edit-name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>คำอธิบาย</label>
                    <textarea name="description" id="edit-description" class="form-control"></textarea>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="submit" name="edit_faculty" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
              </div>
            </form>
          </div>
        </div>
    </div>

    <?php include '../includes/admin_footer.php'; ?>

    <!-- JavaScript สำหรับจัดการโมดอล -->
    <script>
        document.querySelectorAll('.edit-btn').forEach(function(button) {
            button.addEventListener('click', function() {
                var id = this.dataset.id;
                var name = this.dataset.name;
                var description = this.dataset.description;

                document.getElementById('edit-id').value = id;
                document.getElementById('edit-name').value = name;
                document.getElementById('edit-description').value = description;

                var editModal = new bootstrap.Modal(document.getElementById('editModal'));
                editModal.show();
            });
        });
    </script>
</body>
</html>
