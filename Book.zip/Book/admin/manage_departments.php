<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';
include '../classes/Faculty.php';
include '../classes/Department.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

$facultyClass = new Faculty();
$departmentClass = new Department();

$faculties = $facultyClass->getAllFaculties();

// การจัดการการเพิ่ม ลบ แก้ไข สาขาวิชา
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_department'])) {
        $id = $_POST['id'];
        $faculty_id = $_POST['faculty_id'];
        $name = $_POST['name'];
        $description = $_POST['description'];

        $departmentClass->addDepartment($id, $faculty_id, $name, $description);
        header('Location: manage_departments.php');
        exit();
    }

    if (isset($_POST['edit_department'])) {
        $id = $_POST['id'];
        $faculty_id = $_POST['faculty_id'];
        $name = $_POST['name'];
        $description = $_POST['description'];

        $departmentClass->updateDepartment($id, $faculty_id, $name, $description);
        header('Location: manage_departments.php');
        exit();
    }

    if (isset($_POST['delete_department'])) {
        $id = $_POST['id'];

        $departmentClass->deleteDepartment($id);
        header('Location: manage_departments.php');
        exit();
    }
}

// ดึงข้อมูลสาขาวิชาทั้งหมด
$departments = $departmentClass->getAllDepartments();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/admin_header.php'; ?>
    <title>จัดการสาขาวิชา</title>
</head>
<body>
    <?php include '../includes/admin_navbar.php'; ?>

    <div class="container mt-5">
        <h2>จัดการสาขาวิชา</h2>

        <!-- ฟอร์มเพิ่มสาขาวิชา -->
        <h4>เพิ่มสาขาวิชาใหม่</h4>
        <form action="" method="post" class="mb-4">
            <div class="mb-3">
                <label>ID สาขาวิชา</label>
                <input type="text" name="id" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>คณะ</label>
                <select name="faculty_id" class="form-control" required>
                    <option value="">-- เลือกคณะ --</option>
                    <?php foreach ($faculties as $faculty): ?>
                        <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>ชื่อสาขาวิชา</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>คำอธิบาย</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <button type="submit" name="add_department" class="btn btn-success">เพิ่มสาขาวิชา</button>
        </form>

        <!-- ตารางแสดงสาขาวิชา -->
        <h4>รายการสาขาวิชาทั้งหมด</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID สาขาวิชา</th>
                    <th>ชื่อสาขาวิชา</th>
                    <th>คณะ</th>
                    <th>คำอธิบาย</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($departments as $department): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($department['id']); ?></td>
                        <td><?php echo htmlspecialchars($department['name']); ?></td>
                        <td><?php echo htmlspecialchars($department['faculty_name']); ?></td>
                        <td><?php echo htmlspecialchars($department['description']); ?></td>
                        <td>
                            <!-- ปุ่มแก้ไขและลบ -->
                            <form action="" method="post" class="d-inline">
                                <input type="hidden" name="id" value="<?php echo $department['id']; ?>">
                                <button type="button" class="btn btn-primary btn-sm edit-btn" data-id="<?php echo $department['id']; ?>" data-faculty-id="<?php echo $department['faculty_id']; ?>" data-name="<?php echo htmlspecialchars($department['name']); ?>" data-description="<?php echo htmlspecialchars($department['description']); ?>">แก้ไข</button>
                                <button type="submit" name="delete_department" class="btn btn-danger btn-sm" onclick="return confirm('คุณต้องการลบสาขาวิชานี้หรือไม่?')">ลบ</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- โมดอลสำหรับแก้ไขสาขาวิชา -->
        <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <form action="" method="post" class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">แก้ไขสาขาวิชา</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" name="id" id="edit-id">
                <div class="mb-3">
                    <label>คณะ</label>
                    <select name="faculty_id" id="edit-faculty-id" class="form-control" required>
                        <option value="">-- เลือกคณะ --</option>
                        <?php foreach ($faculties as $faculty): ?>
                            <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label>ชื่อสาขาวิชา</label>
                    <input type="text" name="name" id="edit-name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>คำอธิบาย</label>
                    <textarea name="description" id="edit-description" class="form-control"></textarea>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="submit" name="edit_department" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
              </div>
            </form>
          </div>
        </div>
    </div>

    <?php include '../includes/admin_footer.php'; ?>

    <!-- JavaScript สำหรับจัดการโมดอล -->
    <script>
        document.querySelectorAll('.edit-btn').forEach(function(button) {
            button.addEventListener('click', function() {
                var id = this.dataset.id;
                var faculty_id = this.dataset.facultyId;
                var name = this.dataset.name;
                var description = this.dataset.description;

                document.getElementById('edit-id').value = id;
                document.getElementById('edit-faculty-id').value = faculty_id;
                document.getElementById('edit-name').value = name;
                document.getElementById('edit-description').value = description;

                var editModal = new bootstrap.Modal(document.getElementById('editModal'));
                editModal.show();
            });
        });
    </script>
</body>
</html>
