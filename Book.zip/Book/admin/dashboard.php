<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/admin_header.php'; ?>
    <title>แดชบอร์ดผู้ดูแลระบบ</title>
</head>
<body>
    <?php include '../includes/admin_navbar.php'; ?>

    <div class="container mt-5">
        <h1>ยินดีต้อนรับสู่แดชบอร์ดผู้ดูแลระบบ</h1>
        <!-- ส่วนเนื้อหาของแดชบอร์ด -->
    </div>

    <?php include '../includes/admin_footer.php'; ?>
</body>
</html>
