<?php
class Department {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->connection;
    }

    // ฟังก์ชันดึงข้อมูลสาขาวิชาตามคณะ
    public function getDepartmentsByFaculty($faculty_id) {
        $stmt = $this->db->prepare("SELECT * FROM departments WHERE faculty_id = ?");
        $stmt->bind_param("s", $faculty_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // ฟังก์ชันเพิ่มสาขาวิชาใหม่
    public function addDepartment($id, $faculty_id, $name, $description) {
        $stmt = $this->db->prepare("INSERT INTO departments (id, faculty_id, name, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $id, $faculty_id, $name, $description);
        return $stmt->execute();
    }

    // ฟังก์ชันแก้ไขข้อมูลสาขาวิชา
    public function updateDepartment($id, $faculty_id, $name, $description) {
        $stmt = $this->db->prepare("UPDATE departments SET faculty_id = ?, name = ?, description = ? WHERE id = ?");
        $stmt->bind_param("ssss", $faculty_id, $name, $description, $id);
        return $stmt->execute();
    }

    // ฟังก์ชันลบสาขาวิชา
    public function deleteDepartment($id) {
        $stmt = $this->db->prepare("DELETE FROM departments WHERE id = ?");
        $stmt->bind_param("s", $id);
        return $stmt->execute();
    }
    // ในไฟล์ classes/Department.php

public function getAllDepartments() {
    $query = "SELECT d.*, f.name AS faculty_name FROM departments d JOIN faculties f ON d.faculty_id = f.id";
    $result = $this->db->query($query);
    return $result->fetch_all(MYSQLI_ASSOC);
}

}
?>
