<?php
class Product {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->connection;
    }

    // ฟังก์ชันเพิ่มสินค้า
    public function addProduct($name, $description, $price, $stock, $faculty_id, $department_id, $image) {
        $stmt = $this->db->prepare("INSERT INTO products (name, description, price, stock, faculty_id, department_id, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdisss", $name, $description, $price, $stock, $faculty_id, $department_id, $image);
        return $stmt->execute();
    }

    // ฟังก์ชันแก้ไขสินค้า
    public function updateProduct($id, $name, $description, $price, $stock, $faculty_id, $department_id, $image) {
        $stmt = $this->db->prepare("UPDATE products SET name = ?, description = ?, price = ?, stock = ?, faculty_id = ?, department_id = ?, image = ? WHERE id = ?");
        $stmt->bind_param("ssdisssi", $name, $description, $price, $stock, $faculty_id, $department_id, $image, $id);
        return $stmt->execute();
    }

    // ฟังก์ชันลบสินค้า
    public function deleteProduct($id) {
        $stmt = $this->db->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    // ฟังก์ชันดึงข้อมูลสินค้าทั้งหมด
    public function getAllProducts() {
        $query = "SELECT p.*, f.name AS faculty_name, d.name AS department_name FROM products p 
                  LEFT JOIN faculties f ON p.faculty_id = f.id
                  LEFT JOIN departments d ON p.department_id = d.id";
        $result = $this->db->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // ฟังก์ชันดึงสินค้าที่แนะนำ
    public function getFeaturedProducts() {
        $result = $this->db->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 8");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // ฟังก์ชันอื่น ๆ เช่น getProductById(), getProductsByCategory() เป็นต้น
}
?>
