<?php
class Faculty {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->connection;
    }

    // ฟังก์ชันดึงข้อมูลคณะทั้งหมด
    public function getAllFaculties() {
        $result = $this->db->query("SELECT * FROM faculties");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // ฟังก์ชันเพิ่มคณะใหม่
    public function addFaculty($id, $name, $description) {
        $stmt = $this->db->prepare("INSERT INTO faculties (id, name, description) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $id, $name, $description);
        return $stmt->execute();
    }

    // ฟังก์ชันแก้ไขข้อมูลคณะ
    public function updateFaculty($id, $name, $description) {
        $stmt = $this->db->prepare("UPDATE faculties SET name = ?, description = ? WHERE id = ?");
        $stmt->bind_param("sss", $name, $description, $id);
        return $stmt->execute();
    }

    // ฟังก์ชันลบคณะ
    public function deleteFaculty($id) {
        $stmt = $this->db->prepare("DELETE FROM faculties WHERE id = ?");
        $stmt->bind_param("s", $id);
        return $stmt->execute();
    }
}
?>
