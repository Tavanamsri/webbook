<?php
class Database {
    private static $instance = null;
    public $connection;

    private function __construct() {
        // ตรวจสอบว่าไฟล์ config.php มีอยู่จริง
        $config_path = dirname(__DIR__) . '/config/config.php';
        if (!file_exists($config_path)) {
            die("Config file not found at the specified path: $config_path");
        } else {
            include_once $config_path;
        }

        // ใช้ global เพื่อนำตัวแปรจาก config.php เข้ามาใน scope
        global $host, $username, $password, $database, $port, $charset;

        // ตรวจสอบการโหลดตัวแปรจาก config.php
        if (!isset($host, $username, $password, $database, $port, $charset)) {
            echo "Variables are not loaded correctly. Here are the loaded values:";
            var_dump($host, $username, $password, $database, $port, $charset);
            die("Config variables are not loaded properly.");
        }

        // สร้างการเชื่อมต่อฐานข้อมูล
        $this->connection = new mysqli($host, $username, $password, $database, $port);

        // ตรวจสอบการเชื่อมต่อ
        if ($this->connection->connect_error) {
            die("Connection failed: " . $this->connection->connect_error);
        }

        // ตั้งค่า charset ตามที่กำหนดใน config.php
        if (!$this->connection->set_charset($charset)) {
            die("Error loading character set $charset: " . $this->connection->error);
        }
    }

    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
}
?>
