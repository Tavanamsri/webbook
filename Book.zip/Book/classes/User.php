<?php
class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->connection;
    }

    // ฟังก์ชันสมัครสมาชิก
    public function register($firstname, $lastname, $student_id, $email, $hashed_password, $phone, $faculty_id, $department_id, $profile_image) {
        $stmt = $this->db->prepare("INSERT INTO users (firstname, lastname, student_id, email, password, phone, faculty_id, department_id, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssss", $firstname, $lastname, $student_id, $email, $hashed_password, $phone, $faculty_id, $department_id, $profile_image);
        return $stmt->execute();
    }    

    // ฟังก์ชันดึงข้อมูลผู้ใช้โดยอีเมล
    public function getUserByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // ฟังก์ชันดึงข้อมูลผู้ใช้โดย ID
    public function getUserById($user_id) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // ฟังก์ชันอัปเดตโปรไฟล์พร้อมคณะและสาขาวิชา
    public function updateProfileWithFaculty($user_id, $firstname, $lastname, $phone, $email, $faculty_id, $department_id) {
        $stmt = $this->db->prepare("UPDATE users SET firstname = ?, lastname = ?, phone = ?, email = ?, faculty_id = ?, department_id = ? WHERE id = ?");
        $stmt->bind_param("ssssssi", $firstname, $lastname, $phone, $email, $faculty_id, $department_id, $user_id);
        return $stmt->execute();
    }

    // ฟังก์ชันเปลี่ยนรหัสผ่าน
    public function changePassword($user_id, $new_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $this->db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $user_id);
        return $stmt->execute();
    }
    // ในไฟล์ classes/User.php

public function getAllUsers() {
    $result = $this->db->query("SELECT * FROM users");
    return $result->fetch_all(MYSQLI_ASSOC);
}

public function adminUpdateUser($id, $firstname, $lastname, $email, $phone, $role) {
    $stmt = $this->db->prepare("UPDATE users SET firstname = ?, lastname = ?, email = ?, phone = ?, role = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $firstname, $lastname, $email, $phone, $role, $id);
    return $stmt->execute();
}

public function deleteUser($id) {
    $stmt = $this->db->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

}
?>
