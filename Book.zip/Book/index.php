<?php
// เปลี่ยนเส้นทางไปยังหน้าแรก
header('Location: pages/login.php');
exit();
?>