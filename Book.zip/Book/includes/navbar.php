<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <!-- โลโก้ร้านค้า -->
        <a class="navbar-brand" href="../pages/home.php">
            <i class="fas fa-store"></i> ร้านค้ามหาวิทยาลัยราชภัฏอุบลราชธานี
        </a>

        <!-- ปุ่มสำหรับแสดงเมนูบนอุปกรณ์มือถือ -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- เมนู Navbar -->
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../pages/products.php"><i class="fas fa-box"></i> สินค้า</a>
                </li>
                  <?php if ($role === 'admin') { ?>
                <li class="nav-item">
                    <a class="nav-link" href="../pages/faculties.php"><i class="fas fa-university"></i> คณะและสาขาวิชา</a>
                </li>
                  <?php } ?>
                <li class="nav-item">
                    <a class="nav-link" href="../pages/contact_us.php"><i class="fas fa-envelope"></i> ติดต่อเรา</a>
                </li>

                <!-- ตรวจสอบสถานะการเข้าสู่ระบบ -->
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../pages/profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../pages/logout.php"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../pages/login.php"><i class="fas fa-sign-in-alt"></i> เข้าสู่ระบบ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../pages/register.php"><i class="fas fa-user-plus"></i> สมัครสมาชิก</a>
                    </li>
                <?php endif; ?>
                
                <!-- ไอคอนค้นหาและตะกร้าสินค้า -->
                <li class="nav-item">
                    <a class="nav-link" href="../pages/search.php"><i class="fas fa-search"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../pages/cart.php"><i class="fas fa-shopping-cart"></i></a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- ลิงก์ไปยัง Font Awesome และ Bootstrap -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
