<footer class="footer mt-auto py-3 bg-dark text-white">
    <div class="container text-center">
        <span>&copy; 2023 ร้านค้าออนไลน์มหาวิทยาลัยราชภัฏอุบลราชธานี - สงวนลิขสิทธิ์</span>
        <br>
        <small>พัฒนาโดยทีมงานมหาวิทยาลัยราชภัฏอุบลราชธานี</small>
    </div>
</footer>
<!-- Bootstrap and JavaScript dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>
