<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';
include '../classes/Product.php';
// ดึงข้อมูลสินค้าที่แนะนำ
$productClass = new Product();
$featured_products = $productClass->getFeaturedProducts();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/header.php'; ?>
    <title>ร้านค้าออนไลน์มหาวิทยาลัยราชภัฏอุบลราชธานี</title>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <!-- ส่วนของแบนเนอร์หรือสไลด์ -->
    <div class="banner animate__animated animate__fadeIn">
        <h1>ยินดีต้อนรับสู่ร้านค้าออนไลน์มหาวิทยาลัยราชภัฏอุบลราชธานี</h1>
        <p>ค้นหาสินค้าที่คุณต้องการได้ที่นี่</p>
    </div>

    <!-- แสดงสินค้าที่แนะนำ -->
    <div class="container mt-5">
        <h2 class="text-center">สินค้าที่แนะนำ</h2>
        <div class="row">
            <?php foreach ($featured_products as $product): ?>
                <div class="col-md-3">
                    <div class="card mb-4">
                        <img src="<?php echo $base_url; ?>assets/images/<?php echo $product['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                            <p class="card-text"><?php echo number_format($product['price'], 2); ?> บาท</p>
                            <a href="<?php echo $base_url; ?>pages/product_details.php?id=<?php echo $product['id']; ?>" class="btn btn-primary">ดูรายละเอียด</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
</body>
</html>
