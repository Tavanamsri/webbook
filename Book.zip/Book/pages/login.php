<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';
include '../classes/User.php';

$userClass = new User();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // ตรวจสอบผู้ใช้
    $user = $userClass->getUserByEmail($email);

    if ($user) {
        // ตรวจสอบรหัสผ่าน
        if (password_verify($password, $user['password'])) {
            // ตั้งค่าข้อมูลเซสชัน
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['username'] = $user['firstname'];

            // เช็คบทบาทของผู้ใช้เพื่อไปยังหน้าที่ถูกต้อง
            if ($user['role'] == 'admin') {
                header("Location: ../admin/dashboard.php");
            } else {
                header("Location: home.php");
            }
            exit();
        } else {
            $error = "รหัสผ่านไม่ถูกต้อง";
        }
    } else {
        $error = "ไม่พบอีเมลนี้ในระบบ";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/header.php'; ?>
    <title>เข้าสู่ระบบ</title>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">เข้าสู่ระบบ</h2>
        <?php if(isset($error)) { echo '<div class="alert alert-danger">'.$error.'</div>'; } ?>
        <form action="" method="post" class="mx-auto" style="max-width: 400px;">
            <div class="mb-3">
                <label>อีเมล</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>รหัสผ่าน</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">เข้าสู่ระบบ</button>
        </form>
    </div>

    <?php include '../includes/footer.php'; ?>
</body>
</html>
