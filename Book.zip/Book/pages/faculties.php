<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';

// ดึงข้อมูลคณะและสาขาวิชา
$db = Database::getInstance()->connection;
$faculties_result = $db->query("SELECT * FROM faculties");

$faculties = [];
while ($faculty = $faculties_result->fetch_assoc()) {
    $faculty_id = $faculty['id'];
    $stmt = $db->prepare("SELECT * FROM departments WHERE faculty_id = ?");
    $stmt->bind_param("s", $faculty_id);
    $stmt->execute();
    $departments_result = $stmt->get_result();
    $departments = $departments_result->fetch_all(MYSQLI_ASSOC);
    $faculty['departments'] = $departments;
    $faculties[] = $faculty;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/header.php'; ?>
    <title>คณะและสาขาวิชา</title>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">คณะและสาขาวิชา</h2>
        <?php foreach ($faculties as $faculty): ?>
            <div class="faculty">
                <h3><?php echo htmlspecialchars($faculty['name']); ?></h3>
                <ul>
                    <?php foreach ($faculty['departments'] as $department): ?>
                        <li><?php echo htmlspecialchars($department['name']); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>

    <?php include '../includes/footer.php'; ?>
</body>
</html>
