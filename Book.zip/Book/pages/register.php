<?php
include '../config/config.php';
include '../classes/Database.php';
include '../classes/User.php';

$userClass = new User();

// ดึงข้อมูลคณะ
$db = Database::getInstance()->connection;
$faculties_result = $db->query("SELECT * FROM faculties");
$faculties = $faculties_result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $student_id = $_POST['student_id'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $faculty_id = $_POST['faculty_id'];
    $department_id = $_POST['department_id'];
    
    // ตรวจสอบรูปแบบอีเมลบนฝั่งเซิร์ฟเวอร์เฉพาะเมื่อกดส่งข้อมูล
    if (!preg_match('/@(ubru\.ac\.th|live\.ubru\.ac\.th)$/', $email)) {
        $error = "กรุณาใช้อีเมลของนักศึกษาเท่านั้น (@ubru.ac.th หรือ @live.ubru.ac.th)";
    } elseif ($password != $confirm_password) {
        $error = "รหัสผ่านไม่ตรงกัน";
    } else {
        // จัดการอัปโหลดรูปโปรไฟล์
        $profile_image = $_FILES['profile_image']['name'];
        $target_dir = "../assets/profile_images/";
        $target_file = $target_dir . basename($profile_image);
        
        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file)) {
            $existingUser = $userClass->getUserByEmail($email);
            if ($existingUser) {
                $error = "อีเมลนี้ถูกใช้ไปแล้ว";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $register = $userClass->register($firstname, $lastname, $student_id, $email, $hashed_password, $phone, $faculty_id, $department_id, $profile_image);
                if ($register) {
                    header('Location: ../login.php');
                    exit();
                } else {
                    $error = "ไม่สามารถสมัครสมาชิกได้";
                }
            }
        } else {
            $error = "ไม่สามารถอัปโหลดรูปภาพได้";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/header.php'; ?>
    <title>สมัครสมาชิก</title>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">สมัครสมาชิก</h2>
        <?php if(isset($error)) { echo '<div class="alert alert-danger">'.$error.'</div>'; } ?>
        <form action="" method="post" enctype="multipart/form-data" class="mx-auto" style="max-width: 500px;">
            <div class="mb-3">
                <label>ชื่อ</label>
                <input type="text" name="firstname" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>นามสกุล</label>
                <input type="text" name="lastname" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>รหัสนักศึกษา</label>
                <input type="text" name="student_id" class="form-control" required maxlength="11" pattern="\d{11}" title="กรุณากรอกตัวเลข 11 ตัว">
            </div>
            <div class="mb-3">
                <label>เบอร์โทรศัพท์</label>
                <input type="tel" name="phone" class="form-control" required maxlength="10" pattern="\d{10}" title="กรุณากรอกตัวเลข 10 ตัว">
            </div>
            <div class="mb-3">
                <label>อีเมล <label style="color: darkorange;">( เมลมหาวิทยาลัยราชภัฏอุบลราชธานีเท่านั้น )</label></label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>รหัสผ่าน <label style="color: darkorange;">( กรอกไม่เกิน 20 ตัวอักษร )</label></label>
                <input type="password" name="password" class="form-control" id="password" required maxlength="20">
            </div>
            <div class="mb-3">
                <label>ยืนยันรหัสผ่าน</label>
                <input type="password" name="confirm_password" class="form-control" id="confirm_password" required maxlength="20">
            </div>
            <div class="mb-3">
                <label>รูปโปรไฟล์</label>
                <input type="file" name="profile_image" class="form-control" accept="image/*" required>
            </div>
            <div class="mb-3">
                <label>คณะ</label>
                <select name="faculty_id" id="faculty" class="form-control" required>
                    <option value="">-- เลือกคณะ --</option>
                    <?php foreach ($faculties as $faculty): ?>
                        <option value="<?php echo $faculty['id']; ?>">
                            <?php echo htmlspecialchars($faculty['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>สาขาวิชา</label>
                <select name="department_id" id="department" class="form-control" required>
                    <option value="">-- เลือกสาขาวิชา --</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block">สมัครสมาชิก</button>
        </form>
    </div>

    <?php include '../includes/footer.php'; ?>

    <!-- JavaScript สำหรับการตรวจสอบอีเมล -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            function loadDepartments(faculty_id) {
                if (faculty_id) {
                    $.ajax({
                        url: 'get_departments.php',
                        type: 'POST',
                        data: {faculty_id: faculty_id},
                        success: function(data) {
                            $('#department').html(data);
                        }
                    });
                } else {
                    $('#department').html('<option value="">-- เลือกสาขาวิชา --</option>');
                }
            }

            $('#faculty').change(function() {
                var faculty_id = $(this).val();
                loadDepartments(faculty_id);
            });

            // ตรวจสอบรูปแบบอีเมลและการยืนยันรหัสผ่านเมื่อกดส่งฟอร์ม
            $('form').on('submit', function(e) {
                var emailPattern = /@(ubru\.ac\.th|live\.ubru\.ac\.th)$/;
                var email = $('input[name="email"]').val();
                var password = $('#password').val();
                var confirmPassword = $('#confirm_password').val();

                if (!emailPattern.test(email)) {
                    alert("กรุณาใช้อีเมลของนักศึกษาเท่านั้น (@ubru.ac.th หรือ @live.ubru.ac.th)");
                    e.preventDefault(); // ป้องกันไม่ให้ฟอร์มถูกส่ง
                } else if (password !== confirmPassword) {
                    alert("รหัสผ่านไม่ตรงกัน");
                    e.preventDefault(); // ป้องกันไม่ให้ฟอร์มถูกส่ง
                }
            });
        });
    </script>
</body>
</html>
