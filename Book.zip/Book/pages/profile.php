<?php
session_start();
include '../config/config.php';
include '../classes/Database.php';
include '../classes/User.php';
include '../includes/header.php';
include '../includes/navbar.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$userClass = new User();
$user_id = $_SESSION['user_id'];
$user = $userClass->getUserById($user_id);

// ดึงข้อมูลคณะ
$db = Database::getInstance()->connection;
$faculties_result = $db->query("SELECT * FROM faculties");
$faculties = $faculties_result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $faculty_id = $_POST['faculty_id'];
        $department_id = $_POST['department_id'];

        $update = $userClass->updateProfileWithFaculty($user_id, $firstname, $lastname, $phone, $email, $faculty_id, $department_id);
        if ($update) {
            $success = "อัปเดตโปรไฟล์สำเร็จ";
            $_SESSION['username'] = $firstname;
        } else {
            $error = "เกิดข้อผิดพลาดในการอัปเดตโปรไฟล์";
        }
    }
    $user = $userClass->getUserById($user_id);
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <?php include '../includes/header.php'; ?>
    <title>โปรไฟล์ของฉัน</title>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">โปรไฟล์ของฉัน</h2>
        <?php if(isset($success)) { echo '<div class="alert alert-success">'.$success.'</div>'; } ?>
        <?php if(isset($error)) { echo '<div class="alert alert-danger">'.$error.'</div>'; } ?>
        <form action="" method="post" class="mx-auto" style="max-width: 500px;">
            <div class="mb-3">
                <label>ชื่อ</label>
                <input type="text" name="firstname" class="form-control" value="<?php echo htmlspecialchars($user['firstname']); ?>" required>
            </div>
            <div class="mb-3">
                <label>นามสกุล</label>
                <input type="text" name="lastname" class="form-control" value="<?php echo htmlspecialchars($user['lastname']); ?>" required>
            </div>
            <div class="mb-3">
                <label>เบอร์โทรศัพท์</label>
                <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
            </div>
            <div class="mb-3">
                <label>อีเมล</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="mb-3">
                <label>คณะ</label>
                <select name="faculty_id" id="faculty" class="form-control" required>
                    <option value="">-- เลือกคณะ --</option>
                    <?php foreach ($faculties as $faculty): ?>
                        <option value="<?php echo $faculty['id']; ?>" <?php if($user['faculty_id'] == $faculty['id']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($faculty['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>สาขาวิชา</label>
                <select name="department_id" id="department" class="form-control" required>
                    <option value="">-- เลือกสาขาวิชา --</option>
                    <!-- สาขาวิชาจะถูกโหลดโดย JavaScript -->
                </select>
            </div>
            <button type="submit" name="update_profile" class="btn btn-primary btn-block">อัปเดตโปรไฟล์</button>
        </form>
    </div>

    <?php include '../includes/footer.php'; ?>

    <!-- JavaScript สำหรับการโหลดสาขาวิชา -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            function loadDepartments(faculty_id, selected_department_id = null) {
                if (faculty_id) {
                    $.ajax({
                        url: 'get_departments.php',
                        type: 'POST',
                        data: {faculty_id: faculty_id},
                        success: function(data) {
                            $('#department').html(data);
                            if (selected_department_id) {
                                $('#department').val(selected_department_id);
                            }
                        }
                    });
                } else {
                    $('#department').html('<option value="">-- เลือกสาขาวิชา --</option>');
                }
            }

            // โหลดสาขาวิชาตามคณะที่เลือก
            $('#faculty').change(function() {
                var faculty_id = $(this).val();
                loadDepartments(faculty_id);
            });

            // โหลดสาขาวิชาเมื่อเปิดหน้า
            var faculty_id = $('#faculty').val();
            var selected_department_id = '<?php echo $user['department_id']; ?>';
            loadDepartments(faculty_id, selected_department_id);
        });
    </script>
</body>
</html>
