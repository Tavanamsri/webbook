<?php
include '../config/config.php';
include '../classes/Database.php';
include '../includes/header.php';
include '../includes/navbar.php';
if (isset($_POST['faculty_id'])) {
    $faculty_id = $_POST['faculty_id'];
    $db = Database::getInstance()->connection;
    $stmt = $db->prepare("SELECT * FROM departments WHERE faculty_id = ?");
    $stmt->bind_param("s", $faculty_id);
    $stmt->execute();
    $departments_result = $stmt->get_result();

    echo '<option value="">-- เลือกสาขาวิชา --</option>';
    while ($department = $departments_result->fetch_assoc()) {
        echo '<option value="'.$department['id'].'">'.htmlspecialchars($department['name']).'</option>';
    }
}
?>
