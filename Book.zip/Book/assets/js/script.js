// ไฟล์ JavaScript ที่ใช้สำหรับการทำงานทั่วไปในเว็บไซต์ของคุณ
// คุณสามารถเพิ่มโค้ด JavaScript ที่จำเป็นสำหรับการทำงานต่าง ๆ เช่น การยืนยันฟอร์ม หรือการสร้างเอฟเฟกต์ต่าง ๆ

// ตัวอย่าง: การยืนยันฟอร์มสมัครสมาชิก
document.addEventListener('DOMContentLoaded', function() {
    var registerForm = document.querySelector('#registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            var password = document.querySelector('#password').value;
            var confirmPassword = document.querySelector('#confirm_password').value;
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('รหัสผ่านไม่ตรงกัน');
            }
        });
    }
});
document.querySelector("form").addEventListener("submit", function(e) {
    const password = document.querySelector("input[name='password']").value;
    const confirmPassword = document.querySelector("input[name='confirm_password']").value;
    
    if (password !== confirmPassword) {
        e.preventDefault();
        alert("รหัสผ่านไม่ตรงกัน กรุณาลองอีกครั้ง");
    }
});
