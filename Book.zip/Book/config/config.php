<?php
// Database configuration
$host = 'localhost';        // ชื่อโฮสต์ของฐานข้อมูล
$username = 'root';         // ชื่อผู้ใช้ของฐานข้อมูล
$password = '';             // รหัสผ่านของฐานข้อมูล (ค่าเริ่มต้นใน XAMPP คือค่าว่าง)
$database = 'book_db'; // ชื่อฐานข้อมูลที่คุณสร้าง
$port = 3306;               // พอร์ต MySQL (ค่าเริ่มต้นของ MySQL คือ 3306)
$charset = 'utf8mb4';       // ชุดตัวอักษรที่ใช้ในการเชื่อมต่อ

// Debugging and error reporting settings
$debug_mode = true;         // เปิดการดีบั๊ก (true) เพื่อแสดงข้อผิดพลาด
$log_errors = true;         // เปิดการบันทึกข้อผิดพลาด
$error_log_path = dirname(__DIR__) . '/logs/error_log.txt'; // ที่เก็บไฟล์บันทึกข้อผิดพลาด

// Application settings
$app_name = 'University Online Store'; // ชื่อของแอปพลิเคชัน
$app_url = 'http://localhost/Book';    // URL ของแอปพลิเคชัน
$app_timezone = 'Asia/Bangkok';        // โซนเวลาของแอปพลิเคชัน

// Security settings
$session_timeout = 3600;    // ระยะเวลา timeout ของเซสชันในหน่วยวินาที
$cookie_secure = false;     // กำหนดให้ใช้คุกกี้แบบ secure (สำหรับ HTTPS)
$cookie_httponly = true;    // ป้องกันการเข้าถึงคุกกี้ผ่าน JavaScript

// Email settings (ถ้ามีการส่งอีเมล)
$email_host = 'smtp.example.com';   // เซิร์ฟเวอร์ SMTP
$email_username = 'your-email@example.com'; // ชื่อผู้ใช้ SMTP
$email_password = 'your-email-password';    // รหัสผ่าน SMTP
$email_port = 587;                  // พอร์ต SMTP
$email_encryption = 'tls';          // การเข้ารหัส (tls หรือ ssl)

// Check if debugging is enabled, then set error reporting level
if ($debug_mode) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    if ($log_errors) {
        ini_set('log_errors', 1);
        ini_set('error_log', $error_log_path);
    }
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}
?>
