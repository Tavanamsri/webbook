-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2024 at 07:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` varchar(10) NOT NULL,
  `faculty_id` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `faculty_id`, `name`, `description`) VALUES
('B.N.S.', 'K4', 'พยาบาลศาสตร์ (พย.บ.พยาบาลศาสตร์)', NULL),
('B1', 'K3', 'การจัดการธุรกิจระหว่างประเทศ (บธ.บ.การจัดการธุรกิจระหว่างประเทศ)', NULL),
('B10', 'K3', 'การจัดการข้อมูลธุรกิจ (บธ.บ.การจัดการข้อมูลธุรกิจ)', NULL),
('B4', 'K3', 'การจัดการการค้าและการเป็นผู้ประกอบการ (บธ.บ.การจัดการการค้าและการเป็นผู้ประกอบการ)', NULL),
('B5', 'K3', 'การตลาด (บธ.บ.การตลาด)', NULL),
('B6', 'K3', 'การบัญชี (บธ.บ.การบัญชี)', NULL),
('B7', 'K3', 'หลักสูตรบัญชีบัณฑิต (บช.บ.หลักสูตรบัญชีบัณฑิต)', NULL),
('B8', 'K3', 'การบัญชี (ต่อเนื่อง) (บธ.บ.การบัญชี (ต่อเนื่อง))', NULL),
('B9', 'K3', 'นิเทศศาสตร์ (ศศ.บ.นิเทศศาสตร์)', NULL),
('BA1', 'K5', 'การจัดการการท่องเที่ยวและการบริการ (ศศ.บ.การจัดการการท่องเที่ยวและการบริการ)', NULL),
('BA10', 'K5', 'รัฐประศาสนศาสตร์ (รป.บ.รัฐประศาสนศาสตร์)', NULL),
('BA11', 'K5', 'ดนตรีศึกษา (ค.บ.ดนตรีศึกษา)', NULL),
('BA12', 'K5', 'นาฏศิลป์และการละคร (ศป.บ.นาฏศิลป์และการละคร)', NULL),
('BA13', 'K5', 'การพัฒนาชุมชน (ศศ.บ.การพัฒนาชุมชน)', NULL),
('BA14', 'K5', 'ภาษาอังกฤษ (ศศ.บ.ภาษาอังกฤษ)', NULL),
('BA15', 'K5', 'ภาษาอังกฤษธุรกิจ (ศศ.บ.ภาษาอังกฤษธุรกิจ)', NULL),
('BA16', 'K5', 'ภาษาไทย (ศศ.บ.ภาษาไทย)', NULL),
('BA2', 'K5', 'ธุรกิจโรงแรมและที่พัก (ศศ.บ.ธุรกิจโรงแรมและที่พัก)', NULL),
('BA3', 'K5', 'การปกครองท้องถิ่น (รป.บ.การปกครองท้องถิ่น)', NULL),
('BA4', 'K5', 'การเมืองการปกครอง (ร.บ.การเมืองการปกครอง)', NULL),
('BA5', 'K5', 'ภาษาจีน (ศศ.บ.ภาษาจีน)', NULL),
('BA6', 'K5', 'ดนตรี(ศป.บ.ดนตรี)', NULL),
('BA7', 'K5', 'ทัศนศิลป์ (ศป.บ.ทัศนศิลป์)', NULL),
('BA8', 'K5', 'ภาษาอังกฤษและบรรณารักษ์ศึกษา (ค.บ.ภาษาอังกฤษและบรรณารักษ์ศึกษา)', NULL),
('BA9', 'K5', 'ภาษาไทย (ค.บ.ภาษาไทย)', NULL),
('CS1', 'K6', 'วิทยาการคอมพิวเตอร์ (วท.บ.วิทยาการคอมพิวเตอร์)', NULL),
('CS2', 'K6', 'วิศวกรรมซอฟต์แวร์ (วท.บ.วิศวกรรมซอฟต์แวร์)', NULL),
('CS3', 'K6', 'เทคโนโลยีมัลติมีเดียและแอนิเมชัน (วท.บ.เทคโนโลยีมัลติมีเดียและแอนิเมชัน)', NULL),
('E1', 'K1', 'คอมพิวเตอร์ศึกษา (ค.บ.คอมพิวเตอร์ศึกษา)', NULL),
('E10', 'K1', 'เทคโนโลยีดิจิทัลเพื่อการศึกษา (ค.บ.เทคโนโลยีดิจิทัลเพื่อการศึกษา)', NULL),
('E2', 'K1', 'คณิตศาสตร์ (ค.บ.คณิตศาสตร์)', NULL),
('E3', 'K1', 'สังคมศึกษา (ค.บ.สังคมศึกษา)', NULL),
('E4', 'K1', 'พลศึกษา (ค.บ.พลศึกษา)', NULL),
('E5', 'K1', 'การศึกษาพิเศษ (ค.บ.การศึกษาพิเศษ)', NULL),
('E6', 'K1', 'ภาษาอังกฤษ (ค.บ.ภาษาอังกฤษ)', NULL),
('E7', 'K1', 'การประถมศึกษา (ค.บ.การประถมศึกษา)', NULL),
('E8', 'K1', 'วิทยาศาสตร์ทั่วไป (ค.บ.วิทยาศาสตร์ทั่วไป)', NULL),
('E9', 'K1', 'การศึกษาปฐมวัย (ค.บ.การศึกษาปฐมวัย)', NULL),
('LL.B.1', 'K2', 'หลักสูตรนิติศาสตรบัณฑิต (น.บ.หลักสูตรนิติศาสตรบัณฑิต)', NULL),
('S1', 'K7', 'คณิตศาสตร์ (วท.บ.คณิตศาสตร์)', NULL),
('S2', 'K7', 'จุลชีววิทยา (วท.บ.จุลชีววิทยา)', NULL),
('S3', 'K7', 'ชีววิทยา (วท.บ.ชีววิทยา)', NULL),
('S4', 'K7', 'ชีววิทยา (ค.บ.ชีววิทยา)', NULL),
('S5', 'K7', 'ฟิสิกส์ (ค.บ.ฟิสิกส์)', NULL),
('S6', 'K7', 'วิทยาศาสตร์การกีฬาและการออกกำลังกาย (วท.บ.วิทยาศาสตร์การกีฬาและการออกกำลังกาย)', NULL),
('S7', 'K7', 'วิทยาศาสตร์สิ่งแวดล้อม (วท.บ.วิทยาศาสตร์สิ่งแวดล้อม)', NULL),
('S8', 'K7', 'เคมี (วท.บ.เคมี)', NULL),
('S9', 'K7', 'เคมี (ค.บ.เคมี)', NULL),
('ฺB2', 'K3', 'การจัดการธุรกิจดิจิทัล (บธ.บ.การจัดการธุรกิจดิจิทัล)', NULL),
('ฺB3', 'K3', 'การจัดการทั่วไป (บธ.บ.การจัดการทั่วไป)', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `id` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`id`, `name`, `description`) VALUES
('K1', 'คณะครุศาสตร์', NULL),
('K10', 'คณะเทคโนโลยีอุตสาหกรรม', NULL),
('K11', 'คณะแพทย์แผนไทยและแพทย์ทางเลือก', NULL),
('K2', 'คณะนิติศาสตร์', NULL),
('K3', 'คณะบริหารธุรกิจและการจัดการ', NULL),
('K4', 'คณะพยาบาลศาสตร์', NULL),
('K5', 'คณะมนุษยศาสตร์และสังคมศาสตร์', NULL),
('K6', 'คณะวิทยาการคอมพิวเตอร์', NULL),
('K7', 'คณะวิทยาศาสตร์', NULL),
('K8', 'คณะสาธารณสุขศาสตร์', NULL),
('K9', 'คณะเกษตรศาสตร์', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `category_id` int(11) DEFAULT NULL,
  `faculty_id` varchar(10) DEFAULT NULL,
  `department_id` varchar(10) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `faculty_id` varchar(10) DEFAULT NULL,
  `department_id` varchar(10) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `faculty_id` (`faculty_id`);

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `faculty_id` (`faculty_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `faculty_id` (`faculty_id`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
